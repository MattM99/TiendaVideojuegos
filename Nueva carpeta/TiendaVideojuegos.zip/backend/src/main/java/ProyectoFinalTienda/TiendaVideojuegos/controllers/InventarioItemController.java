package ProyectoFinalTienda.TiendaVideojuegos.controllers;

import ProyectoFinalTienda.TiendaVideojuegos.dtos.requests.InventarioItemCreateOrReplaceRequest;
import ProyectoFinalTienda.TiendaVideojuegos.dtos.requests.InventarioItemUpdateRequest;
import ProyectoFinalTienda.TiendaVideojuegos.dtos.requests.ReservaRequest;
import ProyectoFinalTienda.TiendaVideojuegos.dtos.responses.InventarioItemResponse;
import ProyectoFinalTienda.TiendaVideojuegos.dtos.responses.ReservaResponse;
import ProyectoFinalTienda.TiendaVideojuegos.model.enums.Plataformas;
import ProyectoFinalTienda.TiendaVideojuegos.services.InventarioItemService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventario")
@Validated
@Tag(name = "Inventario", description = "Operaciones relacionadas con la gestión del inventario")
public class InventarioItemController {

    @Autowired
    private InventarioItemService inventarioItemService;

    @Operation(summary = "Crear un inventario", description = "Crea una nuevo inventario")
    @PostMapping("/crear")
    public ResponseEntity<InventarioItemResponse> crearInventario(@Valid @RequestBody InventarioItemCreateOrReplaceRequest request) {
        InventarioItemResponse response = inventarioItemService.guardar(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @Operation(summary = "Eliminar un inventario", description = "Elimina un inventario por su ID")
    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<Void> eliminarInventario(@PathVariable int id) {
        inventarioItemService.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Listar todos los inventarios", description = "Devuelve una lista de todos los inventarios")
    @GetMapping("/listar")
    public ResponseEntity<Page<InventarioItemResponse>> listarTodos(
            @RequestParam(defaultValue = "0") int pagina,
            @RequestParam(defaultValue = "10") int tamano,
            @RequestParam(defaultValue = "inventarioItemId") String ordenarPor,
            @RequestParam(defaultValue = "asc") String direccion
    ) {
        Sort sort = direccion.equalsIgnoreCase("desc")
                ? Sort.by(ordenarPor).descending()
                : Sort.by(ordenarPor).ascending();

        Pageable paginacion = PageRequest.of(pagina, tamano, sort);


        return ResponseEntity.ok(
                inventarioItemService.listarTodos(paginacion)
        );
    }

    @Operation(summary = "Obtener un inventario por ID", description = "Devuelve un inventario específico por su ID")
    @GetMapping("/{id}")
    public ResponseEntity<InventarioItemResponse> obtenerPorId(@PathVariable int id) {
        InventarioItemResponse response = inventarioItemService.buscarPorId(id);
        return  ResponseEntity.ok(response);
    }

    @Operation(summary = "Buscar inventarios por videojuego", description = "Devuelve una lista de inventarios que contienen un videojuego específico")
    @GetMapping("/videojuego/{videojuegoId}")
    public ResponseEntity<Page<InventarioItemResponse>> buscarPorVideojuego(
            @PathVariable int videojuegoId,
            @RequestParam(defaultValue = "0") int pagina,
            @RequestParam(defaultValue = "10") int tamano,
            @RequestParam(defaultValue = "inventarioItemId") String ordenarPor,
            @RequestParam(defaultValue = "asc") String direccion
    ) {
        Sort sort = direccion.equalsIgnoreCase("desc")
                ? Sort.by(ordenarPor).descending()
                : Sort.by(ordenarPor).ascending();

        Pageable paginacion = PageRequest.of(pagina, tamano, sort);

        Page<InventarioItemResponse> responses = inventarioItemService.buscarPorVideojuego(videojuegoId, paginacion);

        return ResponseEntity.ok(responses);
    }

    @Operation(
            summary = "Buscar inventarios por plataforma",
            description = "Devuelve una lista de inventarios que pertenecen a una plataforma específica"
    )
    @GetMapping("/plataforma/{plataforma}")
    public ResponseEntity<Page<InventarioItemResponse>> buscarPorPlataforma(
            @PathVariable Plataformas plataforma,
            @RequestParam(defaultValue = "0") int pagina,
            @RequestParam(defaultValue = "10") int tamano,
            @RequestParam(defaultValue = "inventarioItemId") String ordenarPor,
            @RequestParam(defaultValue = "asc") String direccion
    ) {
        Sort sort = direccion.equalsIgnoreCase("desc")
                ? Sort.by(ordenarPor).descending()
                : Sort.by(ordenarPor).ascending();

        Pageable paginacion = PageRequest.of(pagina, tamano, sort);

        Page<InventarioItemResponse> responses =
                inventarioItemService.buscarPorPlataforma(paginacion, plataforma);

        return ResponseEntity.ok(responses);
    }

    @Operation(summary = "Buscar inventarios con precio menor a un valor", description = "Devuelve una lista de inventarios cuyo precio es menor al valor especificado")
    @GetMapping("/precio/menor-a")
    public ResponseEntity<Page<InventarioItemResponse>> buscarMasBaratosQue(
            @RequestParam double valor,
            @RequestParam(defaultValue = "0") int pagina,
            @RequestParam(defaultValue = "10") int tamano,
            @RequestParam(defaultValue = "inventarioItemId") String ordenarPor,
            @RequestParam(defaultValue = "asc") String direccion
    ) {
        Sort sort = direccion.equalsIgnoreCase("desc")
                ? Sort.by(ordenarPor).descending()
                : Sort.by(ordenarPor).ascending();

        Pageable paginacion = PageRequest.of(pagina, tamano, sort);

        Page<InventarioItemResponse> responses = inventarioItemService.buscarMasBaratosQue(valor, paginacion);

        return ResponseEntity.ok(responses);
    }

    @Operation(summary = "Buscar inventarios por plataforma y precio menor a un valor", description = "Devuelve una lista de inventarios que pertenecen a una plataforma específica y cuyo precio es menor al valor especificado")
    @GetMapping("/plataformaPrecio/menor-a")
    public ResponseEntity<Page<InventarioItemResponse>> buscarPorPlataformaMasBaratosQue(
            @RequestParam Plataformas plataforma,
            @RequestParam double valor,
            @RequestParam(defaultValue = "0") int pagina,
            @RequestParam(defaultValue = "10") int tamano,
            @RequestParam(defaultValue = "inventarioItemId") String ordenarPor,
            @RequestParam(defaultValue = "asc") String direccion
    ) {
        Sort sort = direccion.equalsIgnoreCase("desc")
                ? Sort.by(ordenarPor).descending()
                : Sort.by(ordenarPor).ascending();

        Pageable paginacion = PageRequest.of(pagina, tamano, sort);

        Page<InventarioItemResponse> responses = inventarioItemService.buscarPorPlataformaMasBaratosQue(plataforma, valor, paginacion);
        return ResponseEntity.ok(responses);
    }

    @Operation(summary = "Actualizar inventario completo", description = "Actualiza todos los campos de un inventario por ID")
    @PutMapping("/{id}")
    public ResponseEntity<InventarioItemResponse> actualizarInventarioCompleto(
            @PathVariable int id,
            @Valid @RequestBody InventarioItemCreateOrReplaceRequest request) {
        InventarioItemResponse response = inventarioItemService.actualizarCompleto(id, request);
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Actualizar inventario por campo", description = "Actualiza un campo específico de un inventario por ID")
    @PatchMapping("/{id}")
    public ResponseEntity<InventarioItemResponse> actualizarInventarioPorCampo(
            @PathVariable int id,
            @RequestBody InventarioItemUpdateRequest request) {
        InventarioItemResponse response = inventarioItemService.actualizarPorCampo(id, request);
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Agregar stock", description = "Incrementa el stock disponible y total de un inventario")
    @PreAuthorize("hasRole('ADMINISTRADOR')")
    @PatchMapping("/{id}/agregar-stock")
    public ResponseEntity<InventarioItemResponse> agregarStock(
            @PathVariable int id,
            @RequestParam int cantidad) {

        InventarioItemResponse response = inventarioItemService.agregarStock(id, cantidad);
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Dar de baja inventario", description = "Da de baja un inventario (stock en 0)")
    @PreAuthorize("hasRole('ADMINISTRADOR')")
    @PatchMapping("/{id}/baja")
    public ResponseEntity<InventarioItemResponse> darDeBaja(@PathVariable int id) {

        InventarioItemResponse response = inventarioItemService.darDeBaja(id);
        return ResponseEntity.ok(response);
    }

// SOLO PARA PRUEBAS; NO ESTARIA EXPUESTO REALMENTE.
//    @Operation(
//            summary = "Disminuir stock",
//            description = "Reduce el stock disponible de un inventario"
//    )
//    @PreAuthorize("hasRole('ADMINISTRADOR')")
//    @PatchMapping("/{id}/disminuir-stock-disponible")
//    public ResponseEntity<InventarioItemResponse> disminuirStockDisponible(
//            @PathVariable int id,
//            @RequestParam int cantidad) {
//
//        InventarioItemResponse response =
//                inventarioItemService.disminuirStockDisponible(id, cantidad);
//
//        return ResponseEntity.ok(response);
//    }

    // Aggregate root

    @Operation(
            summary = "Crear una reserva",
            description = "Agrega una nueva reserva a la lista de espera de un inventario específico"
    )
    @PostMapping("/{inventarioId}/reservas")
    public ResponseEntity<ReservaResponse> crearReserva(
            @PathVariable Integer inventarioId,
            @Valid @RequestBody ReservaRequest request
    ) {

        ReservaResponse response =
                inventarioItemService.crearReserva(
                        inventarioId,
                        request
                );

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }

    @Operation(
            summary = "Obtener reservas de un inventario",
            description = "Devuelve todas las reservas asociadas a un inventario específico"
    )
    @GetMapping("/{inventarioId}/reservas/listar")
    public ResponseEntity<List<ReservaResponse>> obtenerReservas(
            @PathVariable Integer inventarioId
    ) {

        return ResponseEntity.ok(
                inventarioItemService.obtenerReservas(inventarioId)
        );
    }

}