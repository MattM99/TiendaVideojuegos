package ProyectoFinalTienda.TiendaVideojuegos.dtos.responses;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BloqueoResponse {

    private int bloqueoId;

    private PersonaResponse persona;

    private String fechaInicio;

    private String fechaFin;

    private String motivo;

    private boolean vigente;

}
